#!/usr/bin/env python3
"""
AriNet AtomSpace Viewer v3.0
=============================
Canvas-basierte Visualisierung wie die Hero-Animation.
Fullscreen-fähig. Schwebende Infos. Guardian Cards.

Usage: python atomspace_viewer.py
"""

import sys
import json
import tempfile
import os
import math
import random
from pathlib import Path
from typing import Dict, Any, List

try:
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout,
        QHBoxLayout, QLabel, QPushButton, QFrame
    )
    from PySide6.QtWebEngineWidgets import QWebEngineView
    from PySide6.QtWebEngineCore import QWebEngineSettings
    from PySide6.QtWebChannel import QWebChannel
    from PySide6.QtCore import Qt, QUrl, QObject, Signal, Slot, QTimer
    from PySide6.QtGui import QFont, QColor
    PYSIDE6_AVAILABLE = True
except ImportError:
    PYSIDE6_AVAILABLE = False


# ============================================================
# HTML/CSS/JS - Canvas AtomSpace
# ============================================================
ATOMSPACE_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AriNet AtomSpace</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --bg-black: #000000;
            --bg-deep: #0A0A0F;
            --accent-cyan: #00E5FF;
            --accent-green: #00FF88;
            --accent-magenta: #FF00FF;
            --accent-orange: #FF8800;
            --accent-yellow: #FFF700;
            --accent-red: #FF0044;
            --text-primary: #EAF2FF;
            --text-secondary: #A9B6CC;
            --text-muted: #7C8AA3;
            --font-ui: 'Inter', sans-serif;
            --font-mono: 'JetBrains Mono', monospace;
        }

        body {
            font-family: var(--font-ui);
            background: var(--bg-black);
            color: var(--text-primary);
            overflow: hidden;
            width: 100vw;
            height: 100vh;
        }

        /* Fullscreen Canvas */
        #atomspace-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
        }

        /* Floating HUD - Guardian Card Style */
        .hud-panel {
            position: fixed;
            background: rgba(5, 5, 15, 0.9);
            border: 1px solid rgba(0, 229, 255, 0.2);
            border-radius: 12px;
            padding: 20px;
            backdrop-filter: blur(15px);
            z-index: 100;
            font-style: italic;
        }

        /* Guardian Card - halber Rahmen */
        .guardian-card {
            position: relative;
            background: rgba(5, 5, 15, 0.85);
            border-radius: 12px;
            padding: 20px;
            overflow: hidden;
        }

        .guardian-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, var(--accent-cyan), transparent 70%);
        }

        .guardian-card::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 2px;
            height: 60%;
            background: linear-gradient(180deg, var(--accent-cyan), transparent);
        }

        /* Top Left - Stats */
        #stats-panel {
            top: 20px;
            left: 20px;
            min-width: 220px;
        }

        #stats-panel h1 {
            font-size: 14px;
            color: var(--accent-cyan);
            margin-bottom: 12px;
            font-weight: 600;
        }

        .stat-row {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            font-size: 12px;
            color: var(--text-secondary);
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }

        .stat-value {
            color: var(--text-primary);
            font-family: var(--font-mono);
        }

        .health-bar {
            width: 100%;
            height: 4px;
            background: rgba(255,255,255,0.1);
            border-radius: 2px;
            margin-top: 10px;
            overflow: hidden;
        }

        .health-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--accent-green), var(--accent-cyan));
            border-radius: 2px;
            transition: width 0.5s ease;
        }

        /* Top Right - Clusters */
        #cluster-panel {
            top: 20px;
            right: 20px;
            max-width: 180px;
        }

        #cluster-panel h3 {
            font-size: 12px;
            color: var(--accent-cyan);
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .cluster-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 5px 0;
            font-size: 11px;
            color: var(--text-secondary);
            cursor: pointer;
            transition: color 0.2s;
        }

        .cluster-item:hover {
            color: var(--text-primary);
        }

        .cluster-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
        }

        /* Floating Node Info */
        #node-info {
            position: fixed;
            background: rgba(5, 5, 15, 0.95);
            border: 1px solid rgba(0, 229, 255, 0.3);
            border-radius: 10px;
            padding: 15px 20px;
            pointer-events: none;
            z-index: 200;
            display: none;
            min-width: 200px;
            backdrop-filter: blur(10px);
        }

        #node-info h4 {
            font-size: 14px;
            color: var(--accent-cyan);
            margin-bottom: 8px;
        }

        #node-info p {
            font-size: 11px;
            color: var(--text-secondary);
            margin: 4px 0;
        }

        /* Bottom Bar */
        #bottom-bar {
            bottom: 20px;
            left: 20px;
            right: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .status-text {
            font-size: 11px;
            color: var(--text-muted);
            font-family: var(--font-mono);
        }

        .status-text span {
            color: var(--accent-cyan);
        }

        /* Fullscreen Button */
        #fullscreen-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 40px;
            height: 40px;
            background: rgba(0, 229, 255, 0.1);
            border: 1px solid rgba(0, 229, 255, 0.3);
            border-radius: 8px;
            color: var(--accent-cyan);
            font-size: 18px;
            cursor: pointer;
            z-index: 100;
            transition: all 0.3s;
        }

        #fullscreen-btn:hover {
            background: rgba(0, 229, 255, 0.2);
            border-color: var(--accent-cyan);
        }

        /* Search */
        #search-box {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            width: 300px;
            z-index: 100;
        }

        #search-input {
            width: 100%;
            padding: 10px 15px;
            background: rgba(5, 5, 15, 0.9);
            border: 1px solid rgba(0, 229, 255, 0.2);
            border-radius: 8px;
            color: var(--text-primary);
            font-size: 12px;
            font-family: var(--font-mono);
            outline: none;
        }

        #search-input:focus {
            border-color: var(--accent-cyan);
        }

        #search-input::placeholder {
            color: var(--text-muted);
        }
    </style>
</head>
<body>
    <canvas id="atomspace-canvas"></canvas>

    <!-- Search -->
    <div id="search-box">
        <input type="text" id="search-input" placeholder="Search files, agents, clusters...">
    </div>

    <!-- Stats Panel -->
    <div id="stats-panel" class="hud-panel guardian-card">
        <h1>⚛ AtomSpace v3.0</h1>
        <div class="stat-row"><span>Files</span><span class="stat-value">205</span></div>
        <div class="stat-row"><span>Connections</span><span class="stat-value">81</span></div>
        <div class="stat-row"><span>Agents</span><span class="stat-value">180</span></div>
        <div class="stat-row"><span>Problems</span><span class="stat-value" style="color:#FF0044">77</span></div>
        <div class="health-bar"><div class="health-fill" style="width:62%"></div></div>
    </div>

    <!-- Cluster Panel -->
    <div id="cluster-panel" class="hud-panel guardian-card">
        <h3>Clusters</h3>
        <div class="cluster-item"><span class="cluster-dot" style="background:#4CAF50"></span>Python Bridge (84)</div>
        <div class="cluster-item"><span class="cluster-dot" style="background:#00E5FF"></span>AriNet Core (17)</div>
        <div class="cluster-item"><span class="cluster-dot" style="background:#9C27B0"></span>UI (19)</div>
        <div class="cluster-item"><span class="cluster-dot" style="background:#FF8800"></span>TTS (7)</div>
        <div class="cluster-item"><span class="cluster-dot" style="background:#E91E63"></span>Memory (3)</div>
        <div class="cluster-item"><span class="cluster-dot" style="background:#607D8B"></span>Core (8)</div>
        <div class="cluster-item"><span class="cluster-dot" style="background:#FF00FF"></span>Atomkern (5)</div>
        <div class="cluster-item"><span class="cluster-dot" style="background:#00BCD4"></span>Sandbox (6)</div>
        <div class="cluster-item"><span class="cluster-dot" style="background:#FFF700"></span>Tools (12)</div>
        <div class="cluster-item"><span class="cluster-dot" style="background:#F44336"></span>Security (2)</div>
        <div class="cluster-item"><span class="cluster-dot" style="background:#8BC34A"></span>Behavior Trees (12)</div>
    </div>

    <!-- Floating Node Info -->
    <div id="node-info">
        <h4 id="node-name">Node Name</h4>
        <p id="node-cluster">Cluster: Python Bridge</p>
        <p id="node-size">Size: 45 KB</p>
        <p id="node-connections">Connections: 12</p>
        <p id="node-status">Status: Healthy</p>
    </div>

    <!-- Bottom Bar -->
    <div id="bottom-bar" class="hud-panel guardian-card">
        <div class="status-text">Zoom: <span id="zoom-level">100%</span> | Focus: <span id="focus-node">-</span></div>
        <div class="status-text"><span style="color:#00FF88">●</span> Live | NovaMind 2026</div>
    </div>

    <!-- Fullscreen Button -->
    <button id="fullscreen-btn" onclick="toggleFullscreen()">⛶</button>

    <script>

        // ============================================================
        // CANVAS ATOMSPACE - Wie Hero-Animation
        // ============================================================

        const canvas = document.getElementById('atomspace-canvas');
        const ctx = canvas.getContext('2d');

        let width, height;
        let nodes = [];
        let edges = [];
        let particles = [];
        let hoveredNode = null;
        let selectedNode = null;
        let camera = { x: 0, y: 0, zoom: 1 };
        let isDragging = false;
        let dragStart = { x: 0, y: 0 };

        // Cluster Farben
        const clusterColors = {
            'atomkern': '#FF00FF',
            'python_bridge': '#4CAF50',
            'arinet': '#00E5FF',
            'ui': '#9C27B0',
            'tts': '#FF8800',
            'memory': '#E91E63',
            'core': '#607D8B',
            'sandbox': '#00BCD4',
            'tools': '#FFF700',
            'security': '#F44336',
            'behavior_trees': '#8BC34A'
        };

        // 11 Cluster Nodes + Atomkern
        const clusterData = [
            { id: 'atomkern', label: 'Atomkern', cluster: 'atomkern', size: 45, x: 0, y: 0 },
            { id: 'python_bridge', label: 'Python Bridge', cluster: 'python_bridge', size: 28, x: -280, y: -180 },
            { id: 'arinet', label: 'AriNet Core', cluster: 'arinet', size: 26, x: 280, y: -180 },
            { id: 'ui', label: 'UI', cluster: 'ui', size: 24, x: 320, y: 80 },
            { id: 'tts', label: 'TTS', cluster: 'tts', size: 20, x: 180, y: 240 },
            { id: 'memory', label: 'Memory', cluster: 'memory', size: 18, x: 0, y: 280 },
            { id: 'core', label: 'Core', cluster: 'core', size: 22, x: -180, y: 240 },
            { id: 'sandbox', label: 'Sandbox', cluster: 'sandbox', size: 21, x: -320, y: 80 },
            { id: 'tools', label: 'Tools', cluster: 'tools', size: 23, x: -200, y: -80 },
            { id: 'security', label: 'Security', cluster: 'security', size: 16, x: 200, y: -80, problem: true },
            { id: 'behavior_trees', label: 'Behavior Trees', cluster: 'behavior_trees', size: 23, x: 0, y: -240 }
        ];

        // Datei-Nodes generieren (um jedes Cluster)
        function generateFileNodes() {
            const fileNodes = [];
            let fileId = 0;

            clusterData.forEach(cluster => {
                const fileCount = cluster.id === 'atomkern' ? 5 : 
                                  cluster.id === 'python_bridge' ? 15 :
                                  cluster.id === 'ui' ? 12 :
                                  cluster.id === 'tools' ? 8 :
                                  cluster.id === 'behavior_trees' ? 8 :
                                  cluster.id === 'core' ? 6 : 4;

                for (let i = 0; i < fileCount; i++) {
                    const angle = (i / fileCount) * Math.PI * 2 + (cluster.id.length * 0.5);
                    const radius = cluster.size + 35 + Math.random() * 20;

                    fileNodes.push({
                        id: `file_${cluster.id}_${i}`,
                        label: `module_${i}.py`,
                        cluster: cluster.id,
                        size: 6 + Math.random() * 4,
                        x: cluster.x + Math.cos(angle) * radius,
                        y: cluster.y + Math.sin(angle) * radius,
                        isFile: true,
                        problem: Math.random() < 0.15
                    });
                }
            });

            return fileNodes;
        }

        // Edges generieren
        function generateEdges() {
            const edges = [];

            // Alle Cluster mit Atomkern verbinden
            clusterData.slice(1).forEach(cluster => {
                edges.push({
                    source: cluster.id,
                    target: 'atomkern',
                    weight: 3 + Math.random() * 3
                });
            });

            // Einige Cluster untereinander verbinden
            const crossConnections = [
                ['python_bridge', 'arinet'],
                ['ui', 'arinet'],
                ['tts', 'ui'],
                ['memory', 'core'],
                ['sandbox', 'tools'],
                ['security', 'core']
            ];

            crossConnections.forEach(([a, b]) => {
                edges.push({ source: a, target: b, weight: 1.5 + Math.random() });
            });

            // Dateien mit ihren Clustern verbinden
            nodes.filter(n => n.isFile).forEach(file => {
                edges.push({
                    source: file.id,
                    target: file.cluster,
                    weight: 0.8 + Math.random() * 0.5
                });
            });

            return edges;
        }

        // Initialisierung
        function init() {
            resize();
            window.addEventListener('resize', resize);

            // Nodes erstellen
            nodes = [...clusterData.map(c => ({...c, isFile: false})), ...generateFileNodes()];

            // Edges erstellen
            edges = generateEdges();

            // Kamera zentrieren
            camera.x = width / 2;
            camera.y = height / 2;

            // Event Listener
            canvas.addEventListener('mousemove', onMouseMove);
            canvas.addEventListener('mousedown', onMouseDown);
            canvas.addEventListener('mouseup', onMouseUp);
            canvas.addEventListener('wheel', onWheel);

            // Animation starten
            animate();
        }

        function resize() {
            width = window.innerWidth;
            height = window.innerHeight;
            canvas.width = width;
            canvas.height = height;
        }

        // Maus zu Welt-Koordinaten
        function screenToWorld(sx, sy) {
            return {
                x: (sx - camera.x) / camera.zoom,
                y: (sy - camera.y) / camera.zoom
            };
        }

        // Welt zu Bildschirm
        function worldToScreen(wx, wy) {
            return {
                x: wx * camera.zoom + camera.x,
                y: wy * camera.zoom + camera.y
            };
        }

        // Node unter Maus finden
        function getNodeAt(x, y) {
            const worldPos = screenToWorld(x, y);

            for (let i = nodes.length - 1; i >= 0; i--) {
                const node = nodes[i];
                const dx = worldPos.x - node.x;
                const dy = worldPos.y - node.y;
                const dist = Math.sqrt(dx * dx + dy * dy);

                if (dist < node.size + 5) {
                    return node;
                }
            }
            return null;
        }

        // Mouse Events
        function onMouseMove(e) {
            const rect = canvas.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            if (isDragging) {
                camera.x += x - dragStart.x;
                camera.y += y - dragStart.y;
                dragStart = { x, y };
            } else {
                const newHovered = getNodeAt(x, y);
                if (newHovered !== hoveredNode) {
                    hoveredNode = newHovered;
                    showNodeInfo(hoveredNode, x, y);
                }
            }
        }

        function onMouseDown(e) {
            const rect = canvas.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            isDragging = true;
            dragStart = { x, y };

            const clicked = getNodeAt(x, y);
            if (clicked) {
                selectedNode = clicked;
                document.getElementById('focus-node').textContent = clicked.label;
            }
        }

        function onMouseUp() {
            isDragging = false;
        }

        function onWheel(e) {
            e.preventDefault();
            const zoomSpeed = 0.1;
            const newZoom = camera.zoom * (e.deltaY < 0 ? 1 + zoomSpeed : 1 - zoomSpeed);
            camera.zoom = Math.max(0.3, Math.min(3, newZoom));
            document.getElementById('zoom-level').textContent = Math.round(camera.zoom * 100) + '%';
        }

        // Node Info anzeigen
        function showNodeInfo(node, x, y) {
            const info = document.getElementById('node-info');

            if (!node) {
                info.style.display = 'none';
                return;
            }

            document.getElementById('node-name').textContent = node.label;
            document.getElementById('node-cluster').textContent = 'Cluster: ' + (clusterData.find(c => c.id === node.cluster)?.label || node.cluster);
            document.getElementById('node-size').textContent = 'Size: ' + Math.floor(Math.random() * 80 + 10) + ' KB';

            const connCount = edges.filter(e => e.source === node.id || e.target === node.id).length;
            document.getElementById('node-connections').textContent = 'Connections: ' + connCount;

            const statusEl = document.getElementById('node-status');
            if (node.problem) {
                statusEl.textContent = 'Status: Problem';
                statusEl.style.color = '#FF0044';
            } else {
                statusEl.textContent = 'Status: Healthy';
                statusEl.style.color = '#00FF88';
            }

            info.style.left = Math.min(x + 20, width - 240) + 'px';
            info.style.top = Math.min(y + 20, height - 150) + 'px';
            info.style.display = 'block';
        }

        // Partikel spawnen
        function spawnParticle() {
            if (edges.length === 0) return;

            const edge = edges[Math.floor(Math.random() * edges.length)];
            const sourceNode = nodes.find(n => n.id === edge.source);
            const targetNode = nodes.find(n => n.id === edge.target);

            if (sourceNode && targetNode) {
                particles.push({
                    x: sourceNode.x,
                    y: sourceNode.y,
                    tx: targetNode.x,
                    ty: targetNode.y,
                    progress: 0,
                    speed: 0.008 + Math.random() * 0.008,
                    color: clusterColors[sourceNode.cluster] || '#00E5FF',
                    size: 2 + Math.random() * 2
                });
            }
        }

        // Zeichnen
        function draw() {
            // Clear
            ctx.fillStyle = '#000000';
            ctx.fillRect(0, 0, width, height);

            // Grid (subtil)
            ctx.strokeStyle = 'rgba(0, 229, 255, 0.03)';
            ctx.lineWidth = 1;
            const gridSize = 50 * camera.zoom;
            const offsetX = camera.x % gridSize;
            const offsetY = camera.y % gridSize;

            for (let x = offsetX; x < width; x += gridSize) {
                ctx.beginPath();
                ctx.moveTo(x, 0);
                ctx.lineTo(x, height);
                ctx.stroke();
            }
            for (let y = offsetY; y < height; y += gridSize) {
                ctx.beginPath();
                ctx.moveTo(0, y);
                ctx.lineTo(width, y);
                ctx.stroke();
            }

            // Edges zeichnen
            edges.forEach(edge => {
                const source = nodes.find(n => n.id === edge.source);
                const target = nodes.find(n => n.id === edge.target);
                if (!source || !target) return;

                const s = worldToScreen(source.x, source.y);
                const t = worldToScreen(target.x, target.y);

                ctx.strokeStyle = 'rgba(0, 229, 255, 0.25)';
                ctx.lineWidth = edge.weight * camera.zoom;
                ctx.beginPath();
                ctx.moveTo(s.x, s.y);
                ctx.lineTo(t.x, t.y);
                ctx.stroke();
            });

            // Partikel zeichnen
            particles.forEach((p, i) => {
                p.progress += p.speed;
                if (p.progress >= 1) {
                    particles.splice(i, 1);
                    return;
                }

                const x = p.x + (p.tx - p.x) * p.progress;
                const y = p.y + (p.ty - p.y) * p.progress;
                const screen = worldToScreen(x, y);

                ctx.beginPath();
                ctx.arc(screen.x, screen.y, p.size * camera.zoom, 0, Math.PI * 2);
                ctx.fillStyle = p.color;
                ctx.shadowColor = p.color;
                ctx.shadowBlur = 10;
                ctx.fill();
                ctx.shadowBlur = 0;
            });

            // Nodes zeichnen
            nodes.forEach(node => {
                const screen = worldToScreen(node.x, node.y);
                const size = node.size * camera.zoom;
                const color = node.problem ? '#FF0044' : (clusterColors[node.cluster] || '#00E5FF');

                // Glow
                ctx.shadowColor = color;
                ctx.shadowBlur = node.isFile ? 8 : 20;

                // Node
                ctx.beginPath();
                ctx.arc(screen.x, screen.y, size, 0, Math.PI * 2);
                ctx.fillStyle = color;
                ctx.fill();

                ctx.shadowBlur = 0;

                // Hover-Effekt
                if (node === hoveredNode) {
                    ctx.strokeStyle = '#FFFFFF';
                    ctx.lineWidth = 2;
                    ctx.beginPath();
                    ctx.arc(screen.x, screen.y, size + 4, 0, Math.PI * 2);
                    ctx.stroke();
                }

                // Label für Cluster (bei Zoom > 0.6)
                if (!node.isFile && camera.zoom > 0.6) {
                    ctx.fillStyle = '#EAF2FF';
                    ctx.font = (node.size > 25 ? 'bold 12px' : '11px') + ' Inter';
                    ctx.textAlign = 'center';
                    ctx.fillText(node.label, screen.x, screen.y + size + 15);
                }
            });
        }

        // Animation Loop
        let lastParticleSpawn = 0;
        function animate() {
            draw();

            // Partikel spawnen
            const now = Date.now();
            if (now - lastParticleSpawn > 150) {
                spawnParticle();
                lastParticleSpawn = now;
            }

            requestAnimationFrame(animate);
        }

        // Fullscreen
        function toggleFullscreen() {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen();
            } else {
                document.exitFullscreen();
            }
        }

        // Search
        document.getElementById('search-input').addEventListener('input', function(e) {
            const query = e.target.value.toLowerCase();
            if (!query) return;

            const found = nodes.find(n => n.label.toLowerCase().includes(query));
            if (found) {
                camera.x = width / 2 - found.x * camera.zoom;
                camera.y = height / 2 - found.y * camera.zoom;
                selectedNode = found;
                document.getElementById('focus-node').textContent = found.label;
            }
        });

        // Start
        init();
    </script>
</body>
</html>
"""


# ============================================================
# PYTHON WRAPPER
# ============================================================
if PYSIDE6_AVAILABLE:
    class AtomSpaceBridge(QObject):
        graph_data_ready = Signal(str)
        node_selected = Signal(str)

        def __init__(self, parent=None):
            super().__init__(parent)

        @Slot(result=str)
        def getNetworkData(self):
            return json.dumps({"status": "ok"})
else:
    class AtomSpaceBridge:
        pass


class AtomSpaceViewer(QFrame if PYSIDE6_AVAILABLE else QWidget):
    def __init__(self, parent=None, fullscreen=False):
        super().__init__(parent)
        self.fullscreen = fullscreen
        self._bridge = AtomSpaceBridge() if PYSIDE6_AVAILABLE else None
        self._temp_dir = None
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        if not PYSIDE6_AVAILABLE:
            label = QLabel("PySide6 nicht verfügbar")
            label.setAlignment(Qt.AlignCenter)
            layout.addWidget(label)
            return

        self.browser = QWebEngineView()
        settings = self.browser.page().settings()
        settings.setAttribute(QWebEngineSettings.WebAttribute.WebGLEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.Accelerated2dCanvasEnabled, True)
        layout.addWidget(self.browser)

        self.channel = QWebChannel()
        self.channel.registerObject("bridge", self._bridge)
        self.browser.page().setWebChannel(self.channel)

    def load_visualization(self):
        self._temp_dir = tempfile.mkdtemp(prefix="arinet_atomspace_")
        html_path = os.path.join(self._temp_dir, "index.html")

        with open(html_path, "w", encoding="utf-8") as f:
            f.write(ATOMSPACE_HTML)

        self.browser.setUrl(QUrl.fromLocalFile(html_path))

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            if self.window().isFullScreen():
                self.window().showNormal()
        elif event.key() == Qt.Key_F11:
            if self.window().isFullScreen():
                self.window().showNormal()
            else:
                self.window().showFullScreen()
        super().keyPressEvent(event)


def main():
    if not PYSIDE6_AVAILABLE:
        print("PySide6 nicht installiert. Installiere mit: pip install PySide6")
        sys.exit(1)

    app = QApplication(sys.argv)
    window = QMainWindow()
    window.setWindowTitle("AriNet AtomSpace v3.0")
    window.setStyleSheet("background-color: #000000;")

    screen = app.primaryScreen().geometry()
    window.setGeometry(100, 100, screen.width() - 200, screen.height() - 200)

    viewer = AtomSpaceViewer(fullscreen=False)
    window.setCentralWidget(viewer)
    window.show()

    QTimer.singleShot(500, viewer.load_visualization)

    print("\n⚛ AriNet AtomSpace v3.0")
    print("Shortcuts: F11 = Fullscreen, ESC = Exit Fullscreen")

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
