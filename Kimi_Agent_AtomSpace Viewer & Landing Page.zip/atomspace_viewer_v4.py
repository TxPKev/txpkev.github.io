#!/usr/bin/env python3
"""
AriNet AtomSpace Viewer v4.0
=============================
Polygonale Nodes wie Moltbook. Professionelles Design.
"""

import sys
import json
import tempfile
import os
import math
import random
from pathlib import Path

try:
    from PySide6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QFrame
    from PySide6.QtWebEngineWidgets import QWebEngineView
    from PySide6.QtWebEngineCore import QWebEngineSettings
    from PySide6.QtWebChannel import QWebChannel
    from PySide6.QtCore import Qt, QUrl, QObject, Signal, Slot, QTimer
    PYSIDE6_AVAILABLE = True
except ImportError:
    PYSIDE6_AVAILABLE = False


ATOMSPACE_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AriNet AtomSpace</title>
    <style>
        :root {
            --bg-black: #000000;
            --accent-cyan: #00E5FF;
            --accent-blue: #0088FF;
            --accent-magenta: #FF00FF;
            --accent-green: #00FF88;
            --accent-orange: #FF8800;
            --accent-red: #FF0044;
            --text-primary: #EAF2FF;
            --text-secondary: #A9B6CC;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: var(--bg-black); overflow: hidden; font-family: 'Inter', sans-serif; }

        #canvas { position: fixed; top: 0; left: 0; width: 100%; height: 100%; }

        /* Guardian Card HUD */
        .hud {
            position: fixed;
            background: rgba(5, 8, 15, 0.92);
            border: 1px solid rgba(0, 136, 255, 0.25);
            border-radius: 12px;
            padding: 20px;
            backdrop-filter: blur(15px);
            z-index: 100;
        }

        .hud::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; height: 2px;
            background: linear-gradient(90deg, var(--accent-cyan), transparent 70%);
            border-radius: 12px 12px 0 0;
        }

        .hud::after {
            content: '';
            position: absolute;
            bottom: 0; left: 0; width: 2px; height: 50%;
            background: linear-gradient(180deg, var(--accent-cyan), transparent);
            border-radius: 0 0 0 12px;
        }

        #stats { top: 20px; left: 20px; min-width: 200px; }
        #stats h1 { color: var(--accent-cyan); font-size: 14px; margin-bottom: 12px; font-style: italic; }
        .stat-row { display: flex; justify-content: space-between; font-size: 12px; color: var(--text-secondary); padding: 4px 0; border-bottom: 1px solid rgba(255,255,255,0.05); }
        .stat-value { color: var(--text-primary); font-family: monospace; }

        #clusters { top: 20px; right: 20px; max-width: 170px; }
        #clusters h3 { color: var(--accent-cyan); font-size: 11px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px; }
        .cluster-item { display: flex; align-items: center; gap: 8px; padding: 4px 0; font-size: 11px; color: var(--text-secondary); cursor: pointer; }
        .cluster-dot { width: 8px; height: 8px; border-radius: 2px; }

        /* Info Bubble wie Moltbook */
        #info-bubble {
            position: fixed;
            background: rgba(8, 12, 25, 0.95);
            border: 1px solid rgba(0, 136, 255, 0.4);
            border-radius: 12px;
            padding: 16px 20px;
            min-width: 220px;
            pointer-events: none;
            z-index: 200;
            display: none;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5), 0 0 30px rgba(0, 136, 255, 0.1);
        }

        #info-bubble::before {
            content: '';
            position: absolute;
            top: -6px; left: 20px;
            width: 12px; height: 12px;
            background: rgba(8, 12, 25, 0.95);
            border-left: 1px solid rgba(0, 136, 255, 0.4);
            border-top: 1px solid rgba(0, 136, 255, 0.4);
            transform: rotate(45deg);
        }

        #info-bubble h4 { color: var(--accent-cyan); font-size: 14px; margin-bottom: 8px; }
        #info-bubble p { font-size: 11px; color: var(--text-secondary); margin: 4px 0; }
        #info-bubble .tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 10px; margin-top: 8px; }
        .tag.healthy { background: rgba(0, 255, 136, 0.15); color: var(--accent-green); }
        .tag.problem { background: rgba(255, 0, 68, 0.15); color: var(--accent-red); }

        #bottom-bar { bottom: 20px; left: 20px; right: 20px; display: flex; justify-content: space-between; }
        .status-text { font-size: 11px; color: var(--text-secondary); font-family: monospace; }
        .status-text span { color: var(--accent-cyan); }

        #fullscreen-btn {
            position: fixed; bottom: 20px; right: 20px;
            width: 42px; height: 42px;
            background: rgba(0, 136, 255, 0.1);
            border: 1px solid rgba(0, 136, 255, 0.3);
            border-radius: 8px;
            color: var(--accent-cyan);
            font-size: 18px;
            cursor: pointer;
            z-index: 100;
            transition: all 0.3s;
        }
        #fullscreen-btn:hover { background: rgba(0, 136, 255, 0.2); border-color: var(--accent-cyan); }
    </style>
</head>
<body>
    <canvas id="canvas"></canvas>

    <div id="stats" class="hud">
        <h1>⚛ AtomSpace v4.0</h1>
        <div class="stat-row"><span>Files</span><span class="stat-value">205</span></div>
        <div class="stat-row"><span>Connections</span><span class="stat-value">81</span></div>
        <div class="stat-row"><span>Agents</span><span class="stat-value">180</span></div>
        <div class="stat-row"><span>Problems</span><span class="stat-value" style="color:#FF0044">77</span></div>
    </div>

    <div id="clusters" class="hud">
        <h3>Clusters</h3>
        <div class="cluster-item"><span class="cluster-dot" style="background:#4CAF50"></span>Python Bridge</div>
        <div class="cluster-item"><span class="cluster-dot" style="background:#00E5FF"></span>AriNet Core</div>
        <div class="cluster-item"><span class="cluster-dot" style="background:#9C27B0"></span>UI</div>
        <div class="cluster-item"><span class="cluster-dot" style="background:#FF00FF"></span>Atomkern</div>
        <div class="cluster-item"><span class="cluster-dot" style="background:#FF8800"></span>TTS</div>
        <div class="cluster-item"><span class="cluster-dot" style="background:#E91E63"></span>Memory</div>
    </div>

    <div id="info-bubble">
        <h4 id="bubble-title">Node Name</h4>
        <p id="bubble-cluster">Cluster: Python Bridge</p>
        <p id="bubble-size">Size: 45 KB</p>
        <p id="bubble-connections">Connections: 12</p>
        <span id="bubble-tag" class="tag healthy">Healthy</span>
    </div>

    <div id="bottom-bar" class="hud">
        <div class="status-text">Zoom: <span id="zoom">100%</span> | Focus: <span id="focus">-</span></div>
        <div class="status-text"><span style="color:#00FF88">●</span> Live</div>
    </div>

    <button id="fullscreen-btn" onclick="toggleFullscreen()">⛶</button>

    <script>

        const canvas = document.getElementById('canvas');
        const ctx = canvas.getContext('2d');

        let width, height, camera = { x: 0, y: 0, zoom: 1 };
        let nodes = [], edges = [], particles = [];
        let hoveredNode = null, isDragging = false, dragStart = { x: 0, y: 0 };

        const colors = {
            atomkern: '#FF00FF',
            python: '#4CAF50',
            arinet: '#00E5FF',
            ui: '#9C27B0',
            tts: '#FF8800',
            memory: '#E91E63',
            core: '#607D8B',
            sandbox: '#00BCD4',
            tools: '#FFF700',
            security: '#FF0044',
            bt: '#8BC34A'
        };

        // POLYGONALE NODE - Kristall-Form wie Moltbook
        class PolyNode {
            constructor(id, label, cluster, x, y, size, sides = 6) {
                this.id = id;
                this.label = label;
                this.cluster = cluster;
                this.x = x;
                this.y = y;
                this.size = size;
                this.sides = sides;
                this.color = colors[cluster] || '#00E5FF';
                this.isFile = sides === 6 ? false : true;
                this.problem = Math.random() < 0.15;
                this.pulse = Math.random() * Math.PI * 2;
            }

            // Kristall/Polygon zeichnen
            draw(ctx, screenX, screenY, scale) {
                const size = this.size * scale;
                const pulse = Math.sin(this.pulse + Date.now() * 0.002) * 2;

                // Glow
                ctx.shadowColor = this.problem ? '#FF0044' : this.color;
                ctx.shadowBlur = this.isFile ? 10 : 25;

                // Polygon zeichnen
                ctx.beginPath();
                for (let i = 0; i < this.sides; i++) {
                    const angle = (i / this.sides) * Math.PI * 2 - Math.PI / 2;
                    const r = size + (this.problem ? pulse : 0);
                    const x = screenX + Math.cos(angle) * r;
                    const y = screenY + Math.sin(angle) * r;
                    if (i === 0) ctx.moveTo(x, y);
                    else ctx.lineTo(x, y);
                }
                ctx.closePath();

                // Fill mit Gradient
                const grad = ctx.createRadialGradient(screenX, screenY, 0, screenX, screenY, size * 1.5);
                grad.addColorStop(0, this.problem ? '#FF0044' : this.color);
                grad.addColorStop(0.5, this.problem ? 'rgba(255,0,68,0.5)' : this.color + '80');
                grad.addColorStop(1, 'transparent');
                ctx.fillStyle = grad;
                ctx.fill();

                // Stroke
                ctx.strokeStyle = this.problem ? '#FF6688' : this.color;
                ctx.lineWidth = 2;
                ctx.stroke();

                ctx.shadowBlur = 0;

                // Label für Cluster
                if (!this.isFile && scale > 0.5) {
                    ctx.fillStyle = '#EAF2FF';
                    ctx.font = this.size > 25 ? '600 12px Inter' : '500 10px Inter';
                    ctx.textAlign = 'center';
                    ctx.fillText(this.label, screenX, screenY + size + 16);
                }
            }

            // Hit-Test
            contains(worldX, worldY) {
                const dx = worldX - this.x;
                const dy = worldY - this.y;
                return Math.sqrt(dx * dx + dy * dy) < this.size + 5;
            }
        }

        function init() {
            resize();
            window.addEventListener('resize', resize);

            // Cluster-Nodes (Hexagone)
            const clusterNodes = [
                new PolyNode('atomkern', 'Atomkern', 'atomkern', 0, 0, 40, 6),
                new PolyNode('python', 'Python Bridge', 'python', -250, -150, 26, 6),
                new PolyNode('arinet', 'AriNet Core', 'arinet', 250, -150, 24, 6),
                new PolyNode('ui', 'UI', 'ui', 300, 80, 22, 6),
                new PolyNode('tts', 'TTS', 'tts', 150, 220, 18, 6),
                new PolyNode('memory', 'Memory', 'memory', 0, 260, 16, 6),
                new PolyNode('core', 'Core', 'core', -150, 220, 20, 6),
                new PolyNode('sandbox', 'Sandbox', 'sandbox', -300, 80, 19, 6),
                new PolyNode('tools', 'Tools', 'tools', -180, -60, 21, 6),
                new PolyNode('security', 'Security', 'security', 180, -60, 14, 6),
                new PolyNode('bt', 'Behavior Trees', 'bt', 0, -220, 21, 6)
            ];

            // Datei-Nodes (Dreiecke/Quadrate)
            const fileNodes = [];
            clusterNodes.forEach(cluster => {
                const count = cluster.id === 'atomkern' ? 8 : 4 + Math.floor(Math.random() * 6);
                for (let i = 0; i < count; i++) {
                    const angle = (i / count) * Math.PI * 2 + cluster.id.length;
                    const dist = cluster.size + 35 + Math.random() * 20;
                    const sides = Math.random() > 0.5 ? 4 : 3; // Quadrat oder Dreieck
                    fileNodes.push(new PolyNode(
                        `file_${cluster.id}_${i}`,
                        `module_${i}.py`,
                        cluster.id,
                        cluster.x + Math.cos(angle) * dist,
                        cluster.y + Math.sin(angle) * dist,
                        5 + Math.random() * 3,
                        sides
                    ));
                }
            });

            nodes = [...clusterNodes, ...fileNodes];

            // Edges
            clusterNodes.slice(1).forEach(c => {
                edges.push({ source: c, target: clusterNodes[0], weight: 3 });
            });
            fileNodes.forEach(f => {
                const parent = clusterNodes.find(c => c.id === f.cluster);
                if (parent) edges.push({ source: f, target: parent, weight: 1 });
            });

            // Kamera zentrieren
            camera.x = width / 2;
            camera.y = height / 2;

            // Events
            canvas.addEventListener('mousemove', onMouseMove);
            canvas.addEventListener('mousedown', onMouseDown);
            canvas.addEventListener('mouseup', () => isDragging = false);
            canvas.addEventListener('wheel', onWheel);

            animate();
        }

        function resize() {
            width = window.innerWidth;
            height = window.innerHeight;
            canvas.width = width;
            canvas.height = height;
        }

        function worldToScreen(wx, wy) {
            return { x: wx * camera.zoom + camera.x, y: wy * camera.zoom + camera.y };
        }

        function screenToWorld(sx, sy) {
            return { x: (sx - camera.x) / camera.zoom, y: (sy - camera.y) / camera.zoom };
        }

        function getNodeAt(x, y) {
            const world = screenToWorld(x, y);
            for (let i = nodes.length - 1; i >= 0; i--) {
                if (nodes[i].contains(world.x, world.y)) return nodes[i];
            }
            return null;
        }

        function onMouseMove(e) {
            const rect = canvas.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            if (isDragging) {
                camera.x += x - dragStart.x;
                camera.y += y - dragStart.y;
                dragStart = { x, y };
            } else {
                const newHover = getNodeAt(x, y);
                if (newHover !== hoveredNode) {
                    hoveredNode = newHover;
                    showBubble(hoveredNode, x, y);
                }
            }
        }

        function onMouseDown(e) {
            const rect = canvas.getBoundingClientRect();
            dragStart = { x: e.clientX - rect.left, y: e.clientY - rect.top };
            isDragging = true;
            const clicked = getNodeAt(dragStart.x, dragStart.y);
            if (clicked) {
                document.getElementById('focus').textContent = clicked.label;
            }
        }

        function onWheel(e) {
            e.preventDefault();
            const newZoom = camera.zoom * (e.deltaY < 0 ? 1.1 : 0.9);
            camera.zoom = Math.max(0.3, Math.min(3, newZoom));
            document.getElementById('zoom').textContent = Math.round(camera.zoom * 100) + '%';
        }

        function showBubble(node, x, y) {
            const bubble = document.getElementById('info-bubble');
            if (!node) {
                bubble.style.display = 'none';
                return;
            }

            document.getElementById('bubble-title').textContent = node.label;
            document.getElementById('bubble-cluster').textContent = 'Cluster: ' + node.cluster;
            document.getElementById('bubble-size').textContent = 'Size: ' + Math.floor(Math.random() * 80 + 5) + ' KB';
            document.getElementById('bubble-connections').textContent = 'Connections: ' + 
                edges.filter(e => e.source === node || e.target === node).length;

            const tag = document.getElementById('bubble-tag');
            if (node.problem) {
                tag.textContent = 'Problem';
                tag.className = 'tag problem';
            } else {
                tag.textContent = 'Healthy';
                tag.className = 'tag healthy';
            }

            bubble.style.left = Math.min(x + 15, width - 250) + 'px';
            bubble.style.top = Math.min(y + 15, height - 150) + 'px';
            bubble.style.display = 'block';
        }

        function spawnParticle() {
            if (edges.length === 0 || Math.random() > 0.3) return;
            const edge = edges[Math.floor(Math.random() * edges.length)];
            particles.push({
                x: edge.source.x, y: edge.source.y,
                tx: edge.target.x, ty: edge.target.y,
                progress: 0, speed: 0.01 + Math.random() * 0.01,
                color: edge.source.color
            });
        }

        function draw() {
            ctx.fillStyle = '#000000';
            ctx.fillRect(0, 0, width, height);

            // Grid
            ctx.strokeStyle = 'rgba(0, 136, 255, 0.04)';
            ctx.lineWidth = 1;
            const gs = 50 * camera.zoom;
            for (let x = camera.x % gs; x < width; x += gs) {
                ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke();
            }
            for (let y = camera.y % gs; y < height; y += gs) {
                ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke();
            }

            // Edges
            edges.forEach(e => {
                const s = worldToScreen(e.source.x, e.source.y);
                const t = worldToScreen(e.target.x, e.target.y);
                ctx.strokeStyle = 'rgba(0, 136, 255, 0.2)';
                ctx.lineWidth = e.weight * camera.zoom;
                ctx.beginPath();
                ctx.moveTo(s.x, s.y);
                ctx.lineTo(t.x, t.y);
                ctx.stroke();
            });

            // Particles
            particles.forEach((p, i) => {
                p.progress += p.speed;
                if (p.progress >= 1) { particles.splice(i, 1); return; }
                const x = p.x + (p.tx - p.x) * p.progress;
                const y = p.y + (p.ty - p.y) * p.progress;
                const s = worldToScreen(x, y);
                ctx.beginPath();
                ctx.arc(s.x, s.y, 3 * camera.zoom, 0, Math.PI * 2);
                ctx.fillStyle = p.color;
                ctx.shadowColor = p.color;
                ctx.shadowBlur = 10;
                ctx.fill();
                ctx.shadowBlur = 0;
            });

            // Nodes
            nodes.forEach(n => {
                const s = worldToScreen(n.x, n.y);
                n.draw(ctx, s.x, s.y, camera.zoom);
                n.pulse += 0.02;
            });
        }

        function animate() {
            draw();
            if (Math.random() < 0.1) spawnParticle();
            requestAnimationFrame(animate);
        }

        function toggleFullscreen() {
            if (!document.fullscreenElement) document.documentElement.requestFullscreen();
            else document.exitFullscreen();
        }

        init();
    </script>
</body>
</html>
"""


# Python Wrapper
if PYSIDE6_AVAILABLE:
    class AtomSpaceBridge(QObject):
        pass

class AtomSpaceViewer(QFrame if PYSIDE6_AVAILABLE else QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._temp_dir = None
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        if not PYSIDE6_AVAILABLE:
            from PySide6.QtWidgets import QLabel
            label = QLabel("PySide6 nicht verfügbar")
            label.setAlignment(Qt.AlignCenter)
            layout.addWidget(label)
            return

        self.browser = QWebEngineView()
        settings = self.browser.page().settings()
        settings.setAttribute(QWebEngineSettings.WebAttribute.WebGLEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.Accelerated2dCanvasEnabled, True)
        layout.addWidget(self.browser)

    def load_visualization(self):
        self._temp_dir = tempfile.mkdtemp(prefix="arinet_")
        html_path = os.path.join(self._temp_dir, "index.html")
        with open(html_path, "w", encoding="utf-8") as f:
            f.write(ATOMSPACE_HTML)
        self.browser.setUrl(QUrl.fromLocalFile(html_path))

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape and self.window().isFullScreen():
            self.window().showNormal()
        elif event.key() == Qt.Key_F11:
            self.window().showFullScreen() if not self.window().isFullScreen() else self.window().showNormal()
        super().keyPressEvent(event)


def main():
    if not PYSIDE6_AVAILABLE:
        print("PySide6 nicht installiert")
        sys.exit(1)

    app = QApplication(sys.argv)
    window = QMainWindow()
    window.setWindowTitle("AriNet AtomSpace v4.0")
    window.setStyleSheet("background: #000;")

    screen = app.primaryScreen().geometry()
    window.setGeometry(100, 100, screen.width() - 200, screen.height() - 200)

    viewer = AtomSpaceViewer()
    window.setCentralWidget(viewer)
    window.show()

    QTimer.singleShot(500, viewer.load_visualization)
    print("\n⚛ AriNet AtomSpace v4.0 - Polygonale Nodes")
    print("F11 = Fullscreen, ESC = Exit")

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
