#!/usr/bin/env python3
"""
AriNet Landing Page Generator v3.0
====================================
Mit Guardian Cards und Canvas AtomSpace.
"""

import sys
from pathlib import Path

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AriNet — Your AI. Your Hardware. Your Rules.</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-black: #000000;
            --bg-deep: #0A0A0F;
            --bg-card: #050508;
            --accent-cyan: #00E5FF;
            --accent-green: #00FF88;
            --accent-magenta: #FF00FF;
            --accent-orange: #FF8800;
            --accent-yellow: #FFF700;
            --accent-red: #FF0044;
            --text-primary: #EAF2FF;
            --text-secondary: #A9B6CC;
            --text-muted: #7C8AA3;
            --border-subtle: rgba(0, 229, 255, 0.15);
            --font-ui: 'Inter', sans-serif;
            --font-mono: 'JetBrains Mono', monospace;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        body { font-family: var(--font-ui); background: var(--bg-black); color: var(--text-primary); line-height: 1.6; }

        ::selection { background: rgba(0, 229, 255, 0.3); }

        /* Guardian Card - halber Rahmen */
        .guardian-card {
            position: relative;
            background: rgba(5, 5, 15, 0.85);
            border-radius: 12px;
            padding: 25px;
            overflow: hidden;
        }

        .guardian-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, var(--accent-cyan), transparent 70%);
        }

        .guardian-card::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 2px;
            height: 60%;
            background: linear-gradient(180deg, var(--accent-cyan), transparent);
        }

        /* Navigation */
        .navbar { position: fixed; top: 0; left: 0; right: 0; z-index: 1000; padding: 20px 5%; display: flex; justify-content: space-between; align-items: center; transition: all 0.3s; }
        .navbar.scrolled { background: rgba(0,0,0,0.95); backdrop-filter: blur(20px); border-bottom: 1px solid var(--border-subtle); }
        .nav-logo { height: 35px; }
        .nav-logo img { height: 100%; width: auto; }
        .nav-links { display: flex; gap: 35px; list-style: none; }
        .nav-links a { color: var(--text-secondary); text-decoration: none; font-size: 14px; font-weight: 500; transition: color 0.3s; }
        .nav-links a:hover { color: var(--accent-cyan); }

        @media (max-width: 768px) { .nav-links { display: none; } }

        /* Hero */
        .hero { min-height: 100vh; display: flex; flex-direction: column; justify-content: center; align-items: center; position: relative; overflow: hidden; padding: 120px 5% 80px; }
        #hero-canvas { position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; }
        .hero-content { position: relative; z-index: 1; text-align: center; max-width: 950px; }
        .hero-logo { max-width: 550px; width: 90%; margin-bottom: 15px; filter: drop-shadow(0 0 40px rgba(0,229,255,0.3)); }
        .hero-byline { font-size: 13px; color: var(--text-muted); letter-spacing: 4px; margin-bottom: 25px; text-transform: uppercase; }
        .hero-tagline { font-size: clamp(22px, 4vw, 38px); color: var(--accent-cyan); font-weight: 300; font-style: italic; margin-bottom: 20px; }
        .hero-sub { font-size: clamp(14px, 2vw, 18px); color: var(--text-secondary); max-width: 600px; margin: 0 auto 40px; }
        .hero-ctas { display: flex; gap: 20px; justify-content: center; flex-wrap: wrap; }

        .btn-primary { display: inline-flex; align-items: center; gap: 10px; padding: 16px 40px; background: transparent; border: 2px solid var(--accent-cyan); color: var(--accent-cyan); font-size: 16px; font-weight: 600; text-decoration: none; border-radius: 4px; transition: all 0.3s; }
        .btn-primary:hover { background: rgba(0,229,255,0.1); box-shadow: 0 0 40px rgba(0,229,255,0.3); transform: translateY(-2px); }
        .btn-secondary { padding: 16px 30px; background: transparent; border: 1px solid var(--border-subtle); color: var(--text-secondary); font-size: 14px; text-decoration: none; border-radius: 4px; transition: all 0.3s; }
        .btn-secondary:hover { border-color: var(--accent-cyan); color: var(--accent-cyan); }

        /* Sections */
        .section { padding: 100px 5%; }
        .section-header { text-align: center; max-width: 800px; margin: 0 auto 60px; }
        .section-label { font-size: 12px; color: var(--accent-cyan); text-transform: uppercase; letter-spacing: 3px; margin-bottom: 15px; }
        .section-title { font-size: clamp(32px, 5vw, 52px); font-weight: 800; margin-bottom: 20px; }
        .section-subtitle { font-size: 18px; color: var(--text-secondary); }

        /* Problem */
        .problem-section { background: linear-gradient(180deg, var(--bg-black) 0%, var(--bg-deep) 100%); }
        .problem-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 30px; max-width: 1100px; margin: 0 auto; }
        .problem-card { background: var(--bg-card); border: 1px solid rgba(255,100,100,0.3); border-radius: 12px; padding: 35px 30px; text-align: center; }
        .problem-card h3 { color: #FF8888; font-size: 20px; margin-bottom: 15px; }
        .problem-card p { color: var(--text-secondary); font-size: 15px; }
        .solution-card { background: linear-gradient(135deg, rgba(0,229,255,0.1), rgba(0,255,136,0.05)); border: 1px solid var(--border-subtle); }
        .solution-card h3 { color: var(--accent-cyan); }

        /* Meet Ari */
        .meet-section { background: var(--bg-deep); }
        .meet-content { display: grid; grid-template-columns: 1fr 1.2fr; gap: 60px; align-items: center; max-width: 1300px; margin: 0 auto; }
        .meet-text h3 { font-size: 28px; margin-bottom: 25px; }
        .meet-text p { color: var(--text-secondary); font-size: 16px; line-height: 1.8; margin-bottom: 20px; }
        .meet-text .highlight { color: var(--accent-cyan); font-weight: 500; }
        .app-showcase { background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: 16px; overflow: hidden; }
        .app-showcase img { width: 100%; height: auto; display: block; }

        /* Consciousness */
        .consciousness-section { background: var(--bg-black); }
        .flow-diagram { display: flex; flex-direction: column; gap: 0; max-width: 900px; margin: 0 auto; }
        .flow-row { display: flex; justify-content: center; align-items: center; gap: 15px; flex-wrap: wrap; }
        .flow-box { background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: 10px; padding: 18px 25px; text-align: center; min-width: 160px; }
        .flow-box h4 { font-size: 14px; color: var(--accent-cyan); margin-bottom: 5px; }
        .flow-box p { font-size: 12px; color: var(--text-muted); }
        .flow-arrow { font-size: 24px; color: var(--accent-cyan); }
        .determinism-note { text-align: center; margin-top: 50px; padding: 25px; background: rgba(0,255,136,0.05); border: 1px solid rgba(0,255,136,0.2); border-radius: 10px; }
        .determinism-note p { color: var(--accent-green); font-size: 16px; font-style: italic; }

        /* Features */
        .features-section { background: linear-gradient(180deg, var(--bg-deep) 0%, var(--bg-black) 100%); }
        .features-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 25px; max-width: 1200px; margin: 0 auto; }
        .feature-card { background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: 14px; padding: 35px 30px; transition: all 0.4s; }
        .feature-card:hover { border-color: var(--accent-cyan); transform: translateY(-6px); box-shadow: 0 20px 50px rgba(0,0,0,0.6); }
        .feature-icon { font-size: 44px; margin-bottom: 20px; }
        .feature-card h3 { font-size: 20px; margin-bottom: 15px; }
        .feature-card p { color: var(--text-secondary); font-size: 15px; line-height: 1.7; }

        /* Trio */
        .trio-section { background: var(--bg-black); }
        .trio-container { display: flex; justify-content: center; align-items: center; gap: 25px; flex-wrap: wrap; max-width: 1000px; margin: 0 auto 40px; }
        .trio-card { background: var(--bg-card); border: 2px solid var(--border-subtle); border-radius: 16px; padding: 35px 45px; text-align: center; min-width: 200px; }
        .trio-card:nth-child(1) { border-color: var(--accent-green); }
        .trio-card:nth-child(3) { border-color: var(--accent-cyan); }
        .trio-card:nth-child(5) { border-color: var(--accent-orange); }
        .trio-icon { font-size: 42px; margin-bottom: 15px; }
        .trio-ext { font-size: 26px; font-weight: 700; font-family: var(--font-mono); }
        .trio-ext.py { color: var(--accent-green); }
        .trio-ext.json { color: var(--accent-cyan); }
        .trio-ext.bt { color: var(--accent-orange); }
        .trio-label { font-size: 13px; color: var(--text-muted); margin-top: 8px; }
        .trio-equals { font-size: 36px; color: var(--accent-cyan); }
        .trio-result { background: linear-gradient(135deg, rgba(0,229,255,0.1), rgba(255,0,255,0.05)); border: 2px solid var(--accent-cyan); }
        .trio-result .trio-ext { color: var(--accent-cyan); font-weight: 800; }
        .trio-explanation { text-align: center; max-width: 700px; margin: 0 auto; color: var(--text-secondary); font-size: 16px; }

        /* Comparison */
        .comparison-section { background: var(--bg-deep); }
        .comparison-table { max-width: 1000px; margin: 0 auto; overflow-x: auto; }
        .comp-table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .comp-table th { background: var(--bg-card); padding: 18px 20px; text-align: left; font-weight: 600; border-bottom: 2px solid var(--border-subtle); }
        .comp-table th.ari-header { color: var(--accent-cyan); border-bottom-color: var(--accent-cyan); }
        .comp-table td { padding: 16px 20px; border-bottom: 1px solid var(--border-subtle); color: var(--text-secondary); }
        .comp-table tr:hover td { background: rgba(0,229,255,0.03); }
        .comp-check { color: var(--accent-green); }
        .comp-cross { color: #FF8888; }
        .comp-partial { color: var(--accent-orange); }
        .comp-winner { background: rgba(0,229,255,0.05) !important; }

        /* ATOMSPACE - Canvas */
        .atomspace-section { background: var(--bg-black); padding: 0; }
        .atomspace-container { position: relative; height: 600px; background: var(--bg-black); }
        #atomspace-canvas-landing { width: 100%; height: 100%; }
        .atomspace-overlay { position: absolute; top: 20px; left: 20px; z-index: 10; }
        .atomspace-legend { position: absolute; bottom: 20px; left: 20px; z-index: 10; }
        .legend-item { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; font-size: 12px; color: var(--text-secondary); }
        .legend-dot { width: 10px; height: 10px; border-radius: 50%; }

        /* Desktop */
        .desktop-section { background: linear-gradient(180deg, var(--bg-deep) 0%, var(--bg-black) 100%); }
        .desktop-showcase { max-width: 1100px; margin: 0 auto 50px; }
        .desktop-showcase img { width: 100%; height: auto; border-radius: 12px; border: 1px solid var(--border-subtle); }
        .desktop-features { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; max-width: 900px; margin: 0 auto; }
        .desktop-feature { text-align: center; padding: 20px; }
        .desktop-feature h4 { font-size: 16px; margin-bottom: 8px; }
        .desktop-feature p { font-size: 13px; color: var(--text-secondary); }

        /* Tech */
        .tech-section { background: var(--bg-black); }
        .tech-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; max-width: 1100px; margin: 0 auto; }
        .tech-item { background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: 10px; padding: 25px 20px; text-align: center; transition: all 0.3s; }
        .tech-item:hover { border-color: var(--accent-cyan); background: rgba(0,229,255,0.05); }
        .tech-name { font-family: var(--font-mono); font-size: 16px; font-weight: 600; margin-bottom: 8px; }
        .tech-desc { font-size: 13px; color: var(--text-secondary); }

        /* Timeline */
        .timeline-section { background: var(--bg-deep); }
        .timeline { display: flex; justify-content: center; gap: 30px; flex-wrap: wrap; max-width: 1000px; margin: 0 auto; }
        .timeline-item { background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: 14px; padding: 30px 25px; text-align: center; min-width: 180px; }
        .timeline-item.active { border-color: var(--accent-cyan); background: rgba(0,229,255,0.08); box-shadow: 0 0 40px rgba(0,229,255,0.2); }
        .timeline-year { font-size: 28px; font-weight: 800; color: var(--accent-cyan); font-family: var(--font-mono); margin-bottom: 10px; }
        .timeline-label { font-size: 16px; font-weight: 600; margin-bottom: 10px; }
        .timeline-desc { font-size: 13px; color: var(--text-secondary); }
        .timeline-future { text-align: center; max-width: 700px; margin: 60px auto 0; padding: 30px; background: rgba(255,0,255,0.05); border: 1px solid rgba(255,0,255,0.2); border-radius: 12px; }
        .timeline-future h4 { font-size: 18px; color: var(--accent-magenta); margin-bottom: 10px; }
        .timeline-future p { color: var(--text-secondary); }

        /* CTA */
        .cta-section { background: var(--bg-black); text-align: center; padding: 120px 5%; }
        .cta-content { max-width: 600px; margin: 0 auto; }
        .swiss-badge { font-size: 48px; margin-bottom: 25px; }
        .cta-section h2 { font-size: 36px; margin-bottom: 15px; }
        .cta-section .subtitle { color: var(--text-secondary); font-size: 18px; margin-bottom: 30px; }
        .contest-badge { display: inline-flex; align-items: center; gap: 10px; background: linear-gradient(135deg, rgba(255,0,0,0.1), rgba(255,255,255,0.05)); border: 1px solid rgba(255,0,0,0.3); border-radius: 8px; padding: 12px 25px; font-size: 14px; color: var(--text-secondary); margin-bottom: 40px; }
        .cta-buttons { display: flex; gap: 20px; justify-content: center; flex-wrap: wrap; }
        .btn-large { padding: 18px 45px; font-size: 18px; }
        .contact-email { margin-top: 30px; color: var(--text-muted); font-size: 14px; }
        .contact-email a { color: var(--accent-cyan); text-decoration: none; }

        /* Footer */
        .footer { background: var(--bg-deep); border-top: 1px solid var(--border-subtle); padding: 40px 5%; }
        .footer-content { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px; max-width: 1200px; margin: 0 auto; }
        .footer-left { color: var(--text-muted); font-size: 14px; }
        .footer-right { display: flex; gap: 25px; }
        .footer-link { color: var(--text-secondary); text-decoration: none; font-size: 14px; }
        .footer-link:hover { color: var(--accent-cyan); }

        /* Responsive */
        @media (max-width: 968px) {
            .meet-content { grid-template-columns: 1fr; }
            .trio-container { flex-direction: column; }
            .trio-equals { transform: rotate(90deg); }
        }

        .fade-in { opacity: 0; transform: translateY(30px); transition: all 0.6s ease; }
        .fade-in.visible { opacity: 1; transform: translateY(0); }
    </style>
</head>
<body>
    <nav class="navbar" id="navbar">
        <div class="nav-logo"><img src="assets/logo-arinet-chrome.png" alt="ARINET"></div>
        <ul class="nav-links">
            <li><a href="#meet">Meet Ari</a></li>
            <li><a href="#features">Features</a></li>
            <li><a href="#atomspace">AtomSpace</a></li>
            <li><a href="#comparison">Comparison</a></li>
            <li><a href="#vision">Vision</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
    </nav>

    <section class="hero" id="hero">
        <canvas id="hero-canvas"></canvas>
        <div class="hero-content">
            <img src="assets/logo-arinet-chrome.png" alt="ARINET" class="hero-logo">
            <p class="hero-byline">by NovaMind Studios</p>
            <p class="hero-tagline">Your AI. Your Hardware. Your Rules.</p>
            <p class="hero-sub">The first truly offline AI assistant that learns with you, speaks with you, and grows with you.</p>
            <div class="hero-ctas">
                <a href="#features" class="btn-primary">See What Ari Can Do →</a>
                <a href="#contact" class="btn-secondary">Join Swiss Innovation Contest 2026 →</a>
            </div>
        </div>
    </section>

    <section class="section problem-section" id="problem">
        <div class="section-header">
            <p class="section-label">The Problem</p>
            <h2 class="section-title">Every AI You Use Is a Rental</h2>
            <p class="section-subtitle">You're not the customer. You're the product.</p>
        </div>
        <div class="problem-grid">
            <div class="problem-card fade-in">
                <h3>☁️ Your Data Feeds Their Servers</h3>
                <p>Every conversation you have trains someone else's model. Your private thoughts become their training data.</p>
            </div>
            <div class="problem-card fade-in">
                <h3>💰 You Pay Monthly for Nothing</h3>
                <p>Subscriptions for access to YOUR conversations. Stop paying? Lose everything.</p>
            </div>
            <div class="problem-card solution-highlight fade-in">
                <h3>🖥️ AriNet Is Different</h3>
                <p>Everything runs on YOUR machine. Your data never leaves. You own your AI. Forever.</p>
            </div>
        </div>
    </section>

    <section class="section meet-section" id="meet">
        <div class="section-header">
            <p class="section-label">Meet Ari</p>
            <h2 class="section-title">She Remembers. She Learns. She's Yours.</h2>
        </div>
        <div class="meet-content">
            <div class="meet-text">
                <h3>Your Personal AI Companion</h3>
                <p>Ari runs <span class="highlight">entirely on your machine</span>. She speaks with her own voice. She understands yours. She sees your screen.</p>
                <p>And when you shut her down, she <span class="highlight">saves her state</span> — so next time she picks up exactly where you left off.</p>
                <p>Every conversation makes her smarter. <span class="highlight">Your topics. Your preferences. Your way of thinking.</span></p>
            </div>
            <div class="app-showcase fade-in">
                <img src="assets/ari-chat.png" alt="Ari Chat Interface">
            </div>
        </div>
    </section>

    <section class="section consciousness-section" id="consciousness">
        <div class="section-header">
            <p class="section-label">How Ari Thinks</p>
            <h2 class="section-title">Consciousness Through Architecture</h2>
        </div>
        <div class="flow-diagram">
            <div class="flow-row">
                <div class="flow-box fade-in"><h4>🛑 User Clicks "Quit"</h4><p>Shutdown initiated</p></div>
                <span class="flow-arrow">→</span>
                <div class="flow-box fade-in"><h4>📊 180+ Agents Report</h4><p>Status, tasks, issues</p></div>
                <span class="flow-arrow">→</span>
                <div class="flow-box fade-in"><h4>📝 Rapport Created</h4><p>Session context saved</p></div>
            </div>
            <div style="text-align:center; padding:15px 0;"><span class="flow-arrow">↓</span></div>
            <div class="flow-row">
                <div class="flow-box fade-in"><h4>🚀 Next Startup</h4><p>Ari wakes up</p></div>
                <span class="flow-arrow">→</span>
                <div class="flow-box fade-in"><h4>📋 Rapport Loaded</h4><p>Context restored</p></div>
                <span class="flow-arrow">→</span>
                <div class="flow-box fade-in"><h4>💬 Personalized Greeting</h4><p>"Hey Kev, willkommen zurück!"</p></div>
            </div>
        </div>
        <div class="determinism-note fade-in">
            <p>"Same system state = Same output. Every time. The only thing that varies is Ari's words — the content is always correct."</p>
        </div>
    </section>

    <section class="section features-section" id="features">
        <div class="section-header">
            <p class="section-label">What Ari Can Do</p>
            <h2 class="section-title">Features That Matter</h2>
        </div>
        <div class="features-grid">
            <div class="feature-card fade-in">
                <span class="feature-icon">🗣️</span>
                <h3>Speaks & Listens</h3>
                <p>XTTS-v2 gives Ari her own voice. Whisper lets her understand yours. No cloud. No latency.</p>
            </div>
            <div class="feature-card fade-in">
                <span class="feature-icon">👁️</span>
                <h3>Sees & Understands</h3>
                <p>Florence-2 vision runs locally. Ari can read your screen, analyze documents, understand context visually.</p>
            </div>
            <div class="feature-card fade-in">
                <span class="feature-icon">🧠</span>
                <h3>Remembers & Learns</h3>
                <p>Every conversation adds to Ari's knowledge. She learns YOUR topics, YOUR preferences.</p>
            </div>
            <div class="feature-card fade-in">
                <span class="feature-icon">🔧</span>
                <h3>Repairs Herself</h3>
                <p>Ari knows her own code — all 205 files. She can diagnose problems, find bugs, and fix herself.</p>
            </div>
            <div class="feature-card fade-in">
                <span class="feature-icon">🏗️</span>
                <h3>180+ Specialized Agents</h3>
                <p>Not one AI. A neural network of 180 specialists in 11 clusters, coordinated by Atomkern.</p>
            </div>
            <div class="feature-card fade-in">
                <span class="feature-icon">🔒</span>
                <h3>Zero Cloud. Zero Compromise.</h3>
                <p>Your data never leaves your machine. No API keys. No subscriptions. Complete privacy.</p>
            </div>
        </div>
    </section>

    <section class="section trio-section" id="trio">
        <div class="section-header">
            <p class="section-label">The Trio System</p>
            <h2 class="section-title">Every Agent is Alive</h2>
        </div>
        <div class="trio-container">
            <div class="trio-card fade-in">
                <div class="trio-icon">🐍</div>
                <div class="trio-ext py">.py</div>
                <div class="trio-label">Logic</div>
            </div>
            <div class="trio-equals">+</div>
            <div class="trio-card fade-in">
                <div class="trio-icon">📋</div>
                <div class="trio-ext json">.json</div>
                <div class="trio-label">Metadata</div>
            </div>
            <div class="trio-equals">+</div>
            <div class="trio-card fade-in">
                <div class="trio-icon">🌳</div>
                <div class="trio-ext bt">.bt.xml</div>
                <div class="trio-label">Behavior</div>
            </div>
            <div class="trio-equals">=</div>
            <div class="trio-card trio-result fade-in">
                <div class="trio-icon">🤖</div>
                <div class="trio-ext">.ari</div>
                <div class="trio-label">Agent</div>
            </div>
        </div>
        <p class="trio-explanation fade-in">
            Every AriNet agent knows <strong>what it is</strong> (metadata), <strong>what it can do</strong> (logic), and <strong>how to behave</strong> (behavior tree).
        </p>
    </section>

    <section class="section comparison-section" id="comparison">
        <div class="section-header">
            <p class="section-label">Why AriNet Wins</p>
            <h2 class="section-title">AriNet vs The Competition</h2>
        </div>
        <div class="comparison-table fade-in">
            <table class="comp-table">
                <thead>
                    <tr><th>Feature</th><th>ChatGPT</th><th>MoltBot</th><th>Local LLMs</th><th class="ari-header">AriNet</th></tr>
                </thead>
                <tbody>
                    <tr><td><strong>100% Offline</strong></td><td><span class="comp-cross">✗</span></td><td><span class="comp-partial">△</span></td><td><span class="comp-check">✓</span></td><td class="comp-winner"><span class="comp-check">✓</span> Zero cloud</td></tr>
                    <tr><td><strong>Deterministic</strong></td><td><span class="comp-cross">✗</span></td><td><span class="comp-cross">✗</span></td><td><span class="comp-cross">✗</span></td><td class="comp-winner"><span class="comp-check">✓</span> Same input = same output</td></tr>
                    <tr><td><strong>Native Desktop App</strong></td><td><span class="comp-cross">✗</span></td><td><span class="comp-cross">✗</span></td><td><span class="comp-partial">△</span></td><td class="comp-winner"><span class="comp-check">✓</span> Full PySide6 GUI</td></tr>
                    <tr><td><strong>Session Memory</strong></td><td><span class="comp-cross">✗</span></td><td><span class="comp-cross">✗</span></td><td><span class="comp-cross">✗</span></td><td class="comp-winner"><span class="comp-check">✓</span> Shutdown → Startup awareness</td></tr>
                    <tr><td><strong>Self-Repair</strong></td><td><span class="comp-cross">✗</span></td><td><span class="comp-cross">✗</span></td><td><span class="comp-cross">✗</span></td><td class="comp-winner"><span class="comp-check">✓</span> Knows own code</td></tr>
                    <tr><td><strong>Local TTS Voice</strong></td><td><span class="comp-cross">✗</span></td><td><span class="comp-cross">✗</span></td><td><span class="comp-cross">✗</span></td><td class="comp-winner"><span class="comp-check">✓</span> XTTS-v2 neural</td></tr>
                    <tr><td><strong>Local Vision</strong></td><td><span class="comp-cross">✗</span></td><td><span class="comp-cross">✗</span></td><td><span class="comp-cross">✗</span></td><td class="comp-winner"><span class="comp-check">✓</span> Florence-2 local</td></tr>
                    <tr><td><strong>Non-Coder Friendly</strong></td><td><span class="comp-check">✓</span></td><td><span class="comp-cross">✗</span></td><td><span class="comp-cross">✗</span></td><td class="comp-winner"><span class="comp-check">✓</span> AtomSpace visual editor</td></tr>
                    <tr><td><strong>Context Learning</strong></td><td><span class="comp-partial">△</span></td><td><span class="comp-cross">✗</span></td><td><span class="comp-cross">✗</span></td><td class="comp-winner"><span class="comp-check">✓</span> Learns YOUR topics</td></tr>
                    <tr><td><strong>Data Ownership</strong></td><td><span class="comp-cross">✗</span></td><td><span class="comp-partial">△</span></td><td><span class="comp-check">✓</span></td><td class="comp-winner"><span class="comp-check">✓</span> 100% yours</td></tr>
                </tbody>
            </table>
        </div>
    </section>

    <section class="section atomspace-section" id="atomspace">
        <div class="section-header" style="padding-top: 100px;">
            <p class="section-label">AtomSpace</p>
            <h2 class="section-title">Navigate Your Neural Network</h2>
            <p class="section-subtitle">Visualize, understand, and modify Ari's neural network — no coding required.</p>
        </div>
        <div class="atomspace-container">
            <canvas id="atomspace-canvas-landing"></canvas>
            <div class="atomspace-overlay guardian-card">
                <h4 style="color: var(--accent-cyan); margin-bottom: 10px;">⚛ AtomSpace</h4>
                <p style="font-size: 12px; color: var(--text-muted);">180 Agents | 11 Clusters | 81 Connections</p>
            </div>
            <div class="atomspace-legend guardian-card">
                <div class="legend-item"><span class="legend-dot" style="background:#00FF88"></span>Healthy</div>
                <div class="legend-item"><span class="legend-dot" style="background:#FF0044"></span>Problem</div>
                <div class="legend-item"><span class="legend-dot" style="background:#FF00FF"></span>Atomkern</div>
            </div>
        </div>
    </section>

    <section class="section desktop-section" id="desktop">
        <div class="section-header">
            <p class="section-label">The Desktop App</p>
            <h2 class="section-title">Not a Terminal. A Cockpit.</h2>
        </div>
        <div class="desktop-showcase fade-in">
            <img src="assets/ari-desktop.png" alt="AriNet Desktop App">
        </div>
        <div class="desktop-features">
            <div class="desktop-feature fade-in"><h4>🖥️ Drag & Drop Panels</h4><p>Customize your workspace. Your way.</p></div>
            <div class="desktop-feature fade-in"><h4>🔧 Built-in Sandbox</h4><p>Code editor, file manager, terminal.</p></div>
            <div class="desktop-feature fade-in"><h4>🌐 Integrated Browser</h4><p>Research without leaving Ari.</p></div>
        </div>
    </section>

    <section class="section tech-section" id="tech">
        <div class="section-header">
            <p class="section-label">Built Different</p>
            <h2 class="section-title">Technology Stack</h2>
        </div>
        <div class="tech-grid">
            <div class="tech-item fade-in"><div class="tech-name">PySide6</div><div class="tech-desc">Native desktop performance.</div></div>
            <div class="tech-item fade-in"><div class="tech-name">XTTS-v2</div><div class="tech-desc">Neural speech synthesis.</div></div>
            <div class="tech-item fade-in"><div class="tech-name">Whisper</div><div class="tech-desc">Offline speech recognition.</div></div>
            <div class="tech-item fade-in"><div class="tech-name">Florence-2</div><div class="tech-desc">Local vision AI.</div></div>
            <div class="tech-item fade-in"><div class="tech-name">Local GGUF</div><div class="tech-desc">Your choice of LLM.</div></div>
            <div class="tech-item fade-in"><div class="tech-name">Atomkern</div><div class="tech-desc">Knowledge core engine.</div></div>
            <div class="tech-item fade-in"><div class="tech-name">ZeroMQ</div><div class="tech-desc">Nanosecond messaging.</div></div>
            <div class="tech-item fade-in"><div class="tech-name">C++17</div><div class="tech-desc">When speed matters.</div></div>
            <div class="tech-item fade-in"><div class="tech-name">BehaviorTree.CPP</div><div class="tech-desc">Intelligent agents.</div></div>
        </div>
    </section>

    <section class="section timeline-section" id="vision">
        <div class="section-header">
            <p class="section-label">The Road Ahead</p>
            <h2 class="section-title">Vision & Roadmap</h2>
        </div>
        <div class="timeline">
            <div class="timeline-item fade-in"><div class="timeline-year">2025</div><div class="timeline-label">Foundation</div><div class="timeline-desc">Architecture built.</div></div>
            <div class="timeline-item active fade-in"><div class="timeline-year">2026</div><div class="timeline-label">Launch</div><div class="timeline-desc">Swiss Innovation Contest.</div></div>
            <div class="timeline-item fade-in"><div class="timeline-year">2027</div><div class="timeline-label">Next</div><div class="timeline-desc">Driven by user feedback.</div></div>
            <div class="timeline-item fade-in"><div class="timeline-year">2028</div><div class="timeline-label">Future</div><div class="timeline-desc">What users need most.</div></div>
        </div>
        <div class="timeline-future fade-in">
            <h4>🚀 The Vision</h4>
            <p>Ari becomes what users need her to be. Personalization. Privacy. Control. The direction is shaped by the community.</p>
        </div>
    </section>

    <section class="section cta-section" id="contact">
        <div class="cta-content">
            <div class="swiss-badge">🇨🇭</div>
            <h2>NovaMind Studios</h2>
            <p class="subtitle">Based in Switzerland. Built with precision.</p>
            <div class="contest-badge">🏆 <strong>Swiss Innovation Contest 2026</strong> Participant</div>
            <div class="cta-buttons">
                <a href="mailto:ki27@ik.me" class="btn-primary btn-large">Request Early Access →</a>
                <a href="mailto:ki27@ik.me" class="btn-secondary">Contact for Investment</a>
            </div>
            <p class="contact-email">Kevin Kachramanow — <a href="mailto:ki27@ik.me">ki27@ik.me</a></p>
        </div>
    </section>

    <footer class="footer">
        <div class="footer-content">
            <div class="footer-left">🇨🇭 Built in Switzerland · © 2026 NovaMind Studios</div>
            <div class="footer-right">
                <a href="#" class="footer-link">Privacy</a>
                <a href="#" class="footer-link">Terms</a>
                <a href="#" class="footer-link">GitHub</a>
                <a href="#" class="footer-link">LinkedIn</a>
            </div>
        </div>
    </footer>

    <script>

        // ============================================================
        // HERO CANVAS - Neural Network Animation
        // ============================================================
        function initHeroCanvas() {
            const canvas = document.getElementById('hero-canvas');
            const ctx = canvas.getContext('2d');

            function resize() {
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
            }
            resize();
            window.addEventListener('resize', resize);

            const nodes = [];
            const nodeCount = 45;
            const connectionDistance = 180;

            for (let i = 0; i < nodeCount; i++) {
                nodes.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    vx: (Math.random() - 0.5) * 0.4,
                    vy: (Math.random() - 0.5) * 0.4,
                    size: Math.random() * 2.5 + 1.5,
                    opacity: Math.random() * 0.4 + 0.3
                });
            }

            function animate() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);

                nodes.forEach(node => {
                    node.x += node.vx;
                    node.y += node.vy;
                    if (node.x < 0 || node.x > canvas.width) node.vx *= -1;
                    if (node.y < 0 || node.y > canvas.height) node.vy *= -1;
                });

                for (let i = 0; i < nodes.length; i++) {
                    for (let j = i + 1; j < nodes.length; j++) {
                        const dx = nodes[i].x - nodes[j].x;
                        const dy = nodes[i].y - nodes[j].y;
                        const dist = Math.sqrt(dx * dx + dy * dy);

                        if (dist < connectionDistance) {
                            const opacity = (1 - dist / connectionDistance) * 0.25;
                            ctx.strokeStyle = `rgba(0, 229, 255, ${opacity})`;
                            ctx.lineWidth = 1;
                            ctx.beginPath();
                            ctx.moveTo(nodes[i].x, nodes[i].y);
                            ctx.lineTo(nodes[j].x, nodes[j].y);
                            ctx.stroke();
                        }
                    }
                }

                nodes.forEach(node => {
                    ctx.beginPath();
                    ctx.arc(node.x, node.y, node.size, 0, Math.PI * 2);
                    ctx.fillStyle = `rgba(0, 229, 255, ${node.opacity})`;
                    ctx.shadowColor = '#00E5FF';
                    ctx.shadowBlur = 12;
                    ctx.fill();
                    ctx.shadowBlur = 0;
                });

                requestAnimationFrame(animate);
            }

            animate();
        }

        // ============================================================
        // ATOMSPACE CANVAS - Cluster Visualization
        // ============================================================
        function initAtomSpaceCanvas() {
            const canvas = document.getElementById('atomspace-canvas-landing');
            if (!canvas) return;

            const ctx = canvas.getContext('2d');

            function resize() {
                const rect = canvas.parentElement.getBoundingClientRect();
                canvas.width = rect.width;
                canvas.height = rect.height;
            }
            resize();
            window.addEventListener('resize', resize);

            const clusterColors = {
                'atomkern': '#FF00FF',
                'python_bridge': '#4CAF50',
                'arinet': '#00E5FF',
                'ui': '#9C27B0',
                'tts': '#FF8800',
                'memory': '#E91E63',
                'core': '#607D8B',
                'sandbox': '#00BCD4',
                'tools': '#FFF700',
                'security': '#F44336',
                'behavior_trees': '#8BC34A'
            };

            // Clusters in Kreis-Anordnung
            const clusters = [
                { id: 'atomkern', label: 'Atomkern', x: 0.5, y: 0.5, size: 35, color: '#FF00FF' },
                { id: 'python_bridge', label: 'Python Bridge', x: 0.2, y: 0.25, size: 22, color: '#4CAF50' },
                { id: 'arinet', label: 'AriNet Core', x: 0.8, y: 0.25, size: 20, color: '#00E5FF' },
                { id: 'ui', label: 'UI', x: 0.85, y: 0.55, size: 18, color: '#9C27B0' },
                { id: 'tts', label: 'TTS', x: 0.7, y: 0.8, size: 15, color: '#FF8800' },
                { id: 'memory', label: 'Memory', x: 0.5, y: 0.85, size: 14, color: '#E91E63' },
                { id: 'core', label: 'Core', x: 0.3, y: 0.8, size: 17, color: '#607D8B' },
                { id: 'sandbox', label: 'Sandbox', x: 0.15, y: 0.55, size: 16, color: '#00BCD4' },
                { id: 'tools', label: 'Tools', x: 0.25, y: 0.4, size: 18, color: '#FFF700' },
                { id: 'security', label: 'Security', x: 0.75, y: 0.4, size: 12, color: '#F44336', problem: true },
                { id: 'behavior_trees', label: 'Behavior Trees', x: 0.5, y: 0.15, size: 18, color: '#8BC34A' }
            ];

            // Datei-Nodes generieren
            const fileNodes = [];
            clusters.forEach(cluster => {
                const fileCount = cluster.id === 'atomkern' ? 8 : Math.floor(Math.random() * 8) + 3;
                for (let i = 0; i < fileCount; i++) {
                    const angle = (i / fileCount) * Math.PI * 2 + cluster.id.length;
                    const radius = 0.08 + Math.random() * 0.04;
                    fileNodes.push({
                        x: cluster.x + Math.cos(angle) * radius,
                        y: cluster.y + Math.sin(angle) * radius,
                        size: 3 + Math.random() * 2,
                        color: cluster.color,
                        cluster: cluster.id,
                        isFile: true
                    });
                }
            });

            const allNodes = [...clusters, ...fileNodes];

            // Edges
            const edges = [];
            clusters.slice(1).forEach(c => {
                edges.push({ source: c, target: clusters[0], weight: 2 + Math.random() * 2 });
            });

            fileNodes.forEach(f => {
                const parent = clusters.find(c => c.id === f.cluster);
                if (parent) edges.push({ source: f, target: parent, weight: 0.8 });
            });

            let time = 0;

            function animate() {
                ctx.fillStyle = '#000000';
                ctx.fillRect(0, 0, canvas.width, canvas.height);

                time += 0.005;

                // Grid
                ctx.strokeStyle = 'rgba(0, 229, 255, 0.03)';
                ctx.lineWidth = 1;
                const gridSize = 40;
                for (let x = 0; x < canvas.width; x += gridSize) {
                    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
                }
                for (let y = 0; y < canvas.height; y += gridSize) {
                    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
                }

                // Edges
                edges.forEach(edge => {
                    const sx = edge.source.x * canvas.width + Math.sin(time + edge.source.x * 10) * 3;
                    const sy = edge.source.y * canvas.height + Math.cos(time + edge.source.y * 10) * 3;
                    const tx = edge.target.x * canvas.width + Math.sin(time + edge.target.x * 10) * 3;
                    const ty = edge.target.y * canvas.height + Math.cos(time + edge.target.y * 10) * 3;

                    ctx.strokeStyle = 'rgba(0, 229, 255, 0.2)';
                    ctx.lineWidth = edge.weight;
                    ctx.beginPath();
                    ctx.moveTo(sx, sy);
                    ctx.lineTo(tx, ty);
                    ctx.stroke();
                });

                // Nodes
                allNodes.forEach(node => {
                    const x = node.x * canvas.width + Math.sin(time + node.x * 10) * 3;
                    const y = node.y * canvas.height + Math.cos(time + node.y * 10) * 3;

                    ctx.shadowColor = node.color;
                    ctx.shadowBlur = node.isFile ? 8 : 25;

                    ctx.beginPath();
                    ctx.arc(x, y, node.size, 0, Math.PI * 2);
                    ctx.fillStyle = node.color;
                    ctx.fill();

                    ctx.shadowBlur = 0;

                    // Labels für Cluster
                    if (!node.isFile) {
                        ctx.fillStyle = '#EAF2FF';
                        ctx.font = node.size > 25 ? 'bold 11px Inter' : '10px Inter';
                        ctx.textAlign = 'center';
                        ctx.fillText(node.label, x, y + node.size + 14);
                    }
                });

                requestAnimationFrame(animate);
            }

            animate();
        }

        // ============================================================
        // SCROLL ANIMATIONS
        // ============================================================
        function initScrollAnimations() {
            const fadeElements = document.querySelectorAll('.fade-in');
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) entry.target.classList.add('visible');
                });
            }, { threshold: 0.1 });
            fadeElements.forEach(el => observer.observe(el));
        }

        // ============================================================
        // NAVBAR
        // ============================================================
        function initNavbar() {
            const navbar = document.getElementById('navbar');
            window.addEventListener('scroll', () => {
                navbar.classList.toggle('scrolled', window.scrollY > 50);
            });
        }

        // ============================================================
        // INITIALIZE
        // ============================================================
        document.addEventListener('DOMContentLoaded', () => {
            initHeroCanvas();
            initAtomSpaceCanvas();
            initScrollAnimations();
            initNavbar();
        });
    </script>
</body>
</html>
"""


def generate_landing_page(output_dir: str = "dist") -> str:
    """Generiert die Landing Page."""
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    assets_path = output_path / "assets"
    assets_path.mkdir(exist_ok=True)

    html_file = output_path / "index.html"

    with open(html_file, "w", encoding="utf-8") as f:
        f.write(HTML_TEMPLATE)

    print(f"\n✅ Landing Page v3.0 generiert: {html_file.absolute()}")
    print(f"\n⚠️  Kopiere deine Bilder nach {assets_path.absolute()}/")
    print("   - logo-arinet-chrome.png (Logo)")
    print("   - ari-chat.png (Chat Screenshot)")
    print("   - ari-desktop.png (Desktop Screenshot)")

    return str(html_file)


def main():
    print("\n" + "=" * 65)
    print("🚀 AriNet Landing Page Generator v3.0")
    print("=" * 65)
    print("Mit Guardian Cards und Canvas AtomSpace")
    print("=" * 65 + "\n")

    output_dir = sys.argv[1] if len(sys.argv) > 1 else "dist"
    html_path = generate_landing_page(output_dir)

    print("\n📋 Nächste Schritte:")
    print(f"   1. Kopiere deine Bilder nach {output_dir}/assets/")
    print(f"   2. Öffne {output_dir}/index.html im Browser")

    print("\n" + "=" * 65)
    print("🎉 Fertig! NovaMind Studios")
    print("=" * 65 + "\n")

    return html_path


if __name__ == "__main__":
    main()
